#ifndef TEST_SCOMMAND_H
#define TEST_SCOMMAND_H

#include <check.h>

Suite *scommand_suite (void);

void scommand_memory_test (void);

#endif
